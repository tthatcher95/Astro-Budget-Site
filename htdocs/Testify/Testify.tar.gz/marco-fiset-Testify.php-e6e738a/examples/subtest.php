<?php

$tf->test("An independent test file", function($tf) {
	$tf->pass();
	$tf->assert(true);
});
